"""``tabrion-studio diagnose``: the diagnosis report on the command line (03 section 1, STU-025, TD-036).

``tabrion-studio diagnose [PROJECT] --profile PROFILE [--format markdown|json] [--output FILE [--force]]
[--confirm-prod]`` opens the profile's read-only connection, runs the diagnosis with its backup hints and writes the
same report as ``POST /api/connections/{id}/diagnostics/report`` (:class:`.DiagnosisReports`, the same allowlist: no
password, token, URL or DSN, host, port, user name, database name, file path or value), to standard output (its
bytes, UTF-8 with LF, whatever the stream's encoding) or to ``FILE``. It
needs no running Studio and starts no server; it reads the same configuration as the server for PROJECT:

* **Profiles:** the user's own (``user:<name>``) and, only while the project file is trusted, the project's
  (``project:<name>``). Trust is given in Studio's dialog D-01 in the browser, never here: an untrusted or changed
  project file gives no project profile (``Configuration.entries``).
* **Secrets:** as in the server (keyring, ``env:``, ``file:``). There is no prompt: a profile whose password is
  missing is refused (``studio.secret_missing``).
* **PROD (D-02):** a PROD profile opens only with ``--confirm-prod``, this command's form of the confirmation. The
  registry checks it against the profile as it reads it when it connects (``require_prod_confirmation``, TD-038), the
  same check as the page's; a profile that became PROD after it was named is refused too. The flag has no
  environment variable or setting, so it is given for each run.

* **Output file:** ``--output FILE`` is written atomically as a new 0600 file (a temporary file in the same folder,
  opened with ``O_EXCL`` and ``O_NOFOLLOW``, then moved into place). An existing file is refused unless ``--force``
  is given; a link or anything but a regular file is always refused, and so are the profile's own database file and
  its ``-wal``, ``-shm`` and ``-journal`` files (also through a link or a hard link), since Studio never changes a
  database (M-1 of the PR #85 review). On POSIX the folder is opened once and every later step acts on that opened
  folder (``dir_fd``), so a folder link in the path that changes meanwhile cannot redirect the write (D-1); on
  Windows the path is used again for each step.
* **State directory:** checked like the server's (owner only, no link, not writable by others), never created or
  changed.

Errors are the fixed English texts of the problem catalog (:mod:`tabrion_studio.problems`), never the text of an
exception; log records go to standard error through the log redaction, at warning level and above. Exit codes:
0 the report was written, 1 it could not be made, 2 a usage error (an unknown profile, PROD not confirmed).
"""

from __future__ import annotations

import argparse
from collections.abc import Sequence
import contextlib
import logging
import os
from pathlib import Path
import secrets
import stat
import sys
from typing import Any, TextIO

EXIT_OK = 0
EXIT_ERROR = 1
EXIT_USAGE = 2

_logger = logging.getLogger("tabrion_studio.diagnose")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tabrion-studio diagnose",
        description="Write the diagnosis report of one connection profile (Markdown or JSON, without secrets). "
        "It opens the profile's read-only connection; no Studio needs to run.",
    )
    parser.add_argument("project", nargs="?", default=".", help="project folder (default: the current folder)")
    parser.add_argument(
        "--profile",
        required=True,
        metavar="PROFILE",
        help="the profile: its id (user:NAME or project:NAME) or its name when only one profile has it",
    )
    parser.add_argument(
        "--format", choices=("markdown", "json"), default="markdown", help="report format (default: markdown)"
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        metavar="FILE",
        help="write the report to FILE, a new file with mode 0600 (default: standard output, as UTF-8)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="replace FILE if it exists (never a link, a folder or the profile's own database file)",
    )
    parser.add_argument(
        "--confirm-prod",
        action="store_true",
        help="confirm a connection to a profile marked as PROD (D-02); the connection stays read-only",
    )
    parser.add_argument(
        "--state-dir", type=Path, default=None, help="state directory (default: the per-user state directory)"
    )
    parser.add_argument(
        "--config-dir",
        type=Path,
        default=None,
        help="folder of settings.toml and profiles.toml (default: the per-user configuration folder, "
        "or STATE_DIR/config with --state-dir)",
    )
    return parser


def _say(err: TextIO, code: str, *, note: str | None = None) -> None:
    """A refusal in the catalog's fixed words (never an exception's text)."""
    from tabrion_studio.problems import CATALOG

    entry = CATALOG.get(code)
    if entry is None:
        print(f"tabrion-studio diagnose: {code}", file=err)
    else:
        hint = note if note is not None else entry.hint
        print(f"tabrion-studio diagnose: {entry.title}. {entry.detail}{f' {hint}' if hint else ''} ({code})", file=err)


def _say_db(err: TextIO, error: Any) -> None:
    from tabrion_studio.problems import db_problem

    found = db_problem(error)
    hint = f" {found.hint}" if found.hint else ""
    print(f"tabrion-studio diagnose: {found.title}. {found.detail}{hint} ({found.code})", file=err)


class OutputError(Exception):
    """``--output`` names a file the report may not be written to; the message is a fixed text with the path."""


#: The files next to a SQLite database that belong to it (M-1 of the PR #85 review).
_SIDE_FILES = ("", "-wal", "-shm", "-journal")


def _protected(database_file: Path | None) -> set[str]:
    """The real paths the report must never replace: the profile's database file and its side files."""
    if database_file is None:
        return set()
    real = os.path.realpath(database_file)
    return {os.path.normcase(real + suffix) for suffix in _SIDE_FILES}


def _check_output(target: Path, *, force: bool, protected: set[str]) -> None:
    """Refuse a link, anything but a regular file, an existing file without ``force``, and the database's files."""
    if os.path.normcase(os.path.realpath(target)) in protected:
        raise OutputError(f"{target} is the profile's database or one of its files; Studio never changes a database")
    try:
        info = os.lstat(target)
    except FileNotFoundError:
        return
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
        raise OutputError(f"{target} is a link or not a regular file; give another file name")
    if not force:
        raise OutputError(f"{target} exists; pass --force to replace it")
    for name in protected:  # a hard link to the database is the database too
        with contextlib.suppress(OSError):
            if os.path.samefile(name, target):
                raise OutputError(
                    f"{target} is the profile's database or one of its files; Studio never changes a database"
                )


#: POSIX: the write acts on one opened folder (``dir_fd``), so a folder link swapped meanwhile cannot redirect it
#: (D-1 of the PR #85 review). Windows has no ``dir_fd``; there the checked path is used again.
_IN_FOLDER = sys.platform != "win32" and {os.open, os.stat, os.rename, os.link, os.unlink} <= os.supports_dir_fd


def _folder_opened(folder: int) -> None:
    """A seam for the tests: called right after the output's folder is opened, before anything is written."""


def _write_output(target: Path, body: bytes, *, force: bool, protected: set[str]) -> None:
    """Write ``body`` to ``target`` atomically: a new 0600 file in the same folder (``O_EXCL``, ``O_NOFOLLOW``), then
    moved into place. Without ``force`` the move never replaces a file that appeared meanwhile."""
    _check_output(target, force=force, protected=protected)
    if _IN_FOLDER:
        _write_in_folder(target, body, force=force, protected=protected)
    else:
        _write_by_path(target, body, force=force)


def _check_in_folder(folder: int, target: Path, *, force: bool, protected: set[str]) -> None:
    """``_check_output`` again, on the opened folder: the database's files by the folder's identity and the name,
    and the existing entry without following a link."""
    name = target.name
    here = os.fstat(folder)
    database = f"{target} is the profile's database or one of its files; Studio never changes a database"
    for path in protected:
        with contextlib.suppress(OSError):
            parent = os.stat(os.path.dirname(path))
            if (parent.st_dev, parent.st_ino) == (here.st_dev, here.st_ino) and os.path.normcase(
                os.path.basename(path)
            ) == os.path.normcase(name):
                raise OutputError(database)
    try:
        info = os.stat(name, dir_fd=folder, follow_symlinks=False)
    except FileNotFoundError:
        return
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
        raise OutputError(f"{target} is a link or not a regular file; give another file name")
    if not force:
        raise OutputError(f"{target} exists; pass --force to replace it")
    for path in protected:  # a hard link to the database is the database too
        with contextlib.suppress(OSError):
            known = os.stat(path)
            if (known.st_dev, known.st_ino) == (info.st_dev, info.st_ino):
                raise OutputError(database)


def _write_in_folder(target: Path, body: bytes, *, force: bool, protected: set[str]) -> None:
    """POSIX: open the folder once (its real path, ``O_NOFOLLOW``), check it, then create, move and clean up
    relative to that folder only."""
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)
    folder = os.open(os.path.realpath(target.parent), flags)
    try:
        _folder_opened(folder)
        name = target.name
        _check_in_folder(folder, target, force=force, protected=protected)
        tmp = f".{name}.{os.getpid()}.{secrets.token_hex(4)}.tmp"
        create = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)
        fd = os.open(tmp, create, 0o600, dir_fd=folder)
        try:
            with os.fdopen(fd, "wb") as file:
                file.write(body)
                file.flush()
                os.fsync(file.fileno())
            if force:
                os.replace(tmp, name, src_dir_fd=folder, dst_dir_fd=folder)  # replaces a link itself
            else:
                os.link(tmp, name, src_dir_fd=folder, dst_dir_fd=folder, follow_symlinks=False)  # fails if name exists
                os.unlink(tmp, dir_fd=folder)
        except BaseException:
            with contextlib.suppress(OSError):
                os.unlink(tmp, dir_fd=folder)
            raise
    finally:
        os.close(folder)


def _write_by_path(target: Path, body: bytes, *, force: bool) -> None:
    """Without ``dir_fd`` (Windows): the same steps by path; a folder link in the path is followed each time."""
    folder = target.parent
    tmp = folder / f".{target.name}.{os.getpid()}.{secrets.token_hex(4)}.tmp"
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)
    fd = os.open(tmp, flags, 0o600)
    try:
        with os.fdopen(fd, "wb") as file:
            file.write(body)
            file.flush()
            os.fsync(file.fileno())
        if force:
            os.replace(tmp, target)  # replaces a link itself, never what it points to
        elif sys.platform == "win32":
            os.rename(tmp, target)  # fails when target exists
        else:
            os.link(tmp, target, follow_symlinks=False)  # fails when target exists, atomically
            os.unlink(tmp)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def _write_stdout(out: TextIO, body: bytes) -> None:
    """The report's bytes as they are (UTF-8, LF), whatever the stream's encoding (M-2 of the PR #85 review)."""
    buffer = getattr(out, "buffer", None)
    if buffer is not None:
        out.flush()
        buffer.write(body)
        buffer.flush()
    else:  # a text stream without bytes underneath (tests)
        out.write(body.decode("utf-8"))
        out.flush()


def main(argv: Sequence[str], out: TextIO, err: TextIO) -> int:
    reconfigure = getattr(err, "reconfigure", None)
    if reconfigure is not None:
        # A message that names a profile must not crash on a stream that cannot encode it (M-2).
        with contextlib.suppress(Exception):
            reconfigure(errors="backslashreplace")
    args = build_parser().parse_args(list(argv))
    project = Path(args.project).expanduser()
    if not project.is_dir():
        print(f"tabrion-studio diagnose: not a folder: {project}", file=err)
        return EXIT_USAGE
    project = project.resolve()

    from tabrion_studio.logs import configure_logging

    # Warnings and errors only, to standard error, through the redaction (no log file: this is no Studio instance).
    logs = configure_logging(None, "diagnose", console=err)
    try:
        return _run(args, project, out, err)
    finally:
        logs.close()


def _run(args: argparse.Namespace, project: Path, out: TextIO, err: TextIO) -> int:
    from tabrion.errors import TabrionError

    from tabrion_studio.api.config import Configuration, ProfileEntry
    from tabrion_studio.config.project import ProjectConfig, TrustError
    from tabrion_studio.config.secrets import SecretError
    from tabrion_studio.config.user import UserConfig
    from tabrion_studio.instance import project_key
    from tabrion_studio.paths import (
        STATE_DIR_ENV,
        UnsafePathError,
        check_private_dir,
        default_config_dir,
        default_state_dir,
    )
    from tabrion_studio.services.connections import ConnectionRegistry, HealthError, RegistryError
    from tabrion_studio.services.diagnosis_report import DiagnosisReports, ReportError
    from tabrion_studio.services.diagnostics import Diagnostics
    from tabrion_studio.services.readonly import StatementRefused

    state_dir: Path = args.state_dir if args.state_dir is not None else default_state_dir()
    explicit_state = args.state_dir is not None or bool(os.environ.get(STATE_DIR_ENV))
    config_dir: Path = (
        args.config_dir if args.config_dir is not None else default_config_dir(state_dir if explicit_state else None)
    )
    try:
        # L-4 of the PR #85 review: the server's rule for the folder of the trust records, checked, never changed.
        check_private_dir(state_dir)
    except (OSError, UnsafePathError):
        print(
            f"tabrion-studio diagnose: the state directory {state_dir} is not private (a link, another user's, or "
            "writable by others); fix it before Studio reads its trust records.",
            file=err,
        )
        return EXIT_ERROR
    output: Path | None = None if args.output is None else Path(args.output).expanduser()
    if output is not None:
        try:
            _check_output(output, force=args.force, protected=set())
        except OutputError as exc:
            print(f"tabrion-studio diagnose: {exc}", file=err)
            return EXIT_USAGE
    configuration = Configuration(
        project=ProjectConfig(project, state_dir, project_key(project), config_dir.expanduser().resolve()),
        user=UserConfig(config_dir.expanduser().resolve()),
    )
    project_state = configuration.load_project()
    entries = configuration.entries(project_state)
    wanted = str(args.profile)
    matches: list[ProfileEntry] = [entry for entry in entries if entry.id == wanted]
    if not matches and not wanted.startswith(("user:", "project:")):
        # L-2: an id-shaped value is an id only; a name match could pick a project profile named "user:...".
        matches = [entry for entry in entries if entry.profile.name == wanted]
    if len(matches) > 1:
        names = ", ".join(entry.id for entry in matches)
        print(f"tabrion-studio diagnose: more than one profile is named {wanted!r}; give its id: {names}", file=err)
        return EXIT_USAGE
    if not matches:
        _say(err, "studio.profile_not_found")
        # L-3: say why a profile may be missing: the issues of the user's own file (key paths and codes only).
        for issue in configuration.user.profiles().issues:
            print(f"  profiles.toml: {issue.pointer}: {issue.code}", file=err)
        if project_state.state == "invalid":
            print("The project's profile file has issues; Studio shows them in the connection manager.", file=err)
        if project_state.state in ("untrusted", "changed"):
            print(
                "The project's profiles are used only after you trust them in Studio (dialog D-01): run "
                "tabrion-studio in the project folder and review them.",
                file=err,
            )
        return EXIT_USAGE
    entry = matches[0]
    if entry.profile.environment == "prod" and not args.confirm_prod:
        # D-02 in this command's words; the registry checks it again on the profile it connects to.
        print(
            f"tabrion-studio diagnose: {entry.id} is marked as PROD. Studio stays read-only; the diagnosis is limited "
            "to the profile's statement timeout (15 s by default). Pass --confirm-prod to connect.",
            file=err,
        )
        return EXIT_USAGE

    registry = ConnectionRegistry(configuration)
    diagnostics = Diagnostics(registry)
    reports = DiagnosisReports(registry, diagnostics, clock=diagnostics.clock)
    try:
        connection = registry.open(entry.id, confirmed_environment="prod" if args.confirm_prod else None)
        protected = _protected(connection.database_file)
        report = reports.build(connection.id, args.format)
    except RegistryError as exc:
        _say(err, exc.code)
        return (
            EXIT_USAGE if exc.code in ("studio.prod_confirmation_required", "studio.profile_not_found") else EXIT_ERROR
        )
    except SecretError as exc:
        note = (
            "Store the password in the system keyring (Studio's connection manager), or reference it with env: or "
            "file: in the profile."
            if exc.code == "studio.secret_missing"
            else None
        )
        _say(err, exc.code, note=note)
        return EXIT_USAGE if exc.code == "studio.profile_not_found" else EXIT_ERROR
    except (TrustError, ReportError, StatementRefused) as exc:
        _say(err, exc.code)
        return EXIT_ERROR
    except HealthError as exc:
        _say_db(err, exc.classification)
        return EXIT_ERROR
    except TabrionError as exc:
        _say_db(err, exc)
        return EXIT_ERROR
    except Exception:
        # Through the log redaction (types and frames only, never the message), like the server's internal error.
        _logger.error("diagnosis report failed", exc_info=True, extra={"event": "studio.diagnosis_report_failed"})
        print("tabrion-studio diagnose: the report could not be made (an unexpected error, see above).", file=err)
        return EXIT_ERROR
    finally:
        registry.close_all()
    try:
        if output is None:
            _write_stdout(out, report.body)
        else:
            _write_output(output, report.body, force=args.force, protected=protected)
    except OutputError as exc:
        print(f"tabrion-studio diagnose: {exc}", file=err)
        return EXIT_USAGE
    except OSError as exc:
        where = "standard output" if output is None else str(output)
        print(f"tabrion-studio diagnose: cannot write {where}: {exc.strerror or type(exc).__name__}", file=err)
        return EXIT_ERROR
    if output is not None:
        print(f"Report written to {output} ({report.filename}).", file=err)
    return EXIT_OK


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main(sys.argv[1:], sys.stdout, sys.stderr))
